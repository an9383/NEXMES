﻿#region < HEADER AREA >
// *---------------------------------------------------------------------------------------------*
//   Form ID      : AP0017
//   Form Name    : 수주없이 생산계획생성
//   Name Space   : WIZ.AP
//   Created Date : 2020-07-07
//   Made By      : jejun
//   Description  :
// *---------------------------------------------------------------------------------------------*
#endregion

#region < USING AREA >
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

using WIZ.PopUp;
using WIZ.Control;

using Infragistics.Win.UltraWinGrid;
using System.Collections.Generic;
using System.Text;
#endregion

namespace WIZ.AP
{
    public partial class AP0017 : WIZ.Forms.BaseMDIChildForm
    {
        #region < MEMBER AREA >
        private bool bNew = false;

        UltraGridUtil _GridUtil = new UltraGridUtil();

        BizTextBoxManager btbManager = new BizTextBoxManager();
        BizGridManager bizGridManager;

        Common _Common = new Common();

        DataTable rtnDtTemp = new DataTable();
        DataTable rtnDtTemp2 = new DataTable();

        DataTable dtGrid;
        DataTable dtGrid2;

        List <int> SeqCheck = new List<int>();
        #endregion

        #region < CONSTRUCTOR >
        public AP0017()
        {
            InitializeComponent();
        }
        #endregion

        #region < FORM LOAD >
        private void AP0017_Load(object sender, EventArgs e)
        {
            GridInitialize();

            splitContainer1.SplitterDistance = 0; // 숨김처리

        }

        private void BtbManager_PopUpClosed(object tCode, object tName, bool bFindOK)
        {
            SBtnTextEditor sCode = tCode as SBtnTextEditor;
            SBtnTextEditor sName = tName as SBtnTextEditor;

            if (tCode != null)
            {
                if (sCode.Name == "txt_ITEMCODE_S")
                {
                    StringBuilder sSQL = new StringBuilder();
                    sSQL.Append("Select BACKCOLOR FROM BM0010 with (NOLOCK) where ITEMCODE = '" + sCode.Text.Trim() + "' ");

                    DBHelper db = new DBHelper();

                    DataTable dt = db.FillTable(sSQL.ToString());

                    sCode.Appearance.BackColor = Color.White;
                    sName.Appearance.BackColor = Color.White;

                    if (dt.Rows.Count == 1)
                    {
                        string sBackColor = DBHelper.nvlString(dt.Rows[0]["BACKCOLOR"]);
                        Color _color = ColorTranslator.FromHtml(sBackColor);

                        sCode.Appearance.BackColor = _color;
                        sName.Appearance.BackColor = _color;
                    }
                }
            }
        }

        private void GridInitialize()
        {
            try
            {
                //grid2              
                _GridUtil.InitializeGrid(grid2, true, true, false, "", false);
                _GridUtil.InitColumnUltraGrid(grid2, "CHK", "선택", false, GridColDataType_emu.CheckBox, 70, 100, Infragistics.Win.HAlign.Center, true, false);
                _GridUtil.InitColumnUltraGrid(grid2, "PLANTCODE", "사업장", false, GridColDataType_emu.VarChar, 100, 0, Infragistics.Win.HAlign.Left, true, true);
                _GridUtil.InitColumnUltraGrid(grid2, "PLANNO", "생산지시번호", false, GridColDataType_emu.VarChar, 120, 0, Infragistics.Win.HAlign.Center, true, false);
                _GridUtil.InitColumnUltraGrid(grid2, "RECDATE", "생산지시일자", false, GridColDataType_emu.VarChar, 100, 0, Infragistics.Win.HAlign.Center, true, true);
                _GridUtil.InitColumnUltraGrid(grid2, "ITEMCODE", "품목", false, GridColDataType_emu.VarChar, 100, 0, Infragistics.Win.HAlign.Left, true, true);
                _GridUtil.InitColumnUltraGrid(grid2, "ITEMNAME", "품명", false, GridColDataType_emu.VarChar, 200, 0, Infragistics.Win.HAlign.Left, true, true);
                _GridUtil.InitColumnUltraGrid(grid2, "UNITCODE", "단위", false, GridColDataType_emu.VarChar, 60, 0, Infragistics.Win.HAlign.Left, true, false);
                _GridUtil.InitColumnUltraGrid(grid2, "PLANQTY", "생산계획수량", false, GridColDataType_emu.VarChar, 100, 0, Infragistics.Win.HAlign.Right, true, true, "#,###,###");
                _GridUtil.InitColumnUltraGrid(grid2, "SETQTY", "지시편성수량", false, GridColDataType_emu.VarChar, 100, 0, Infragistics.Win.HAlign.Right, false, false, "#,###,###");
                _GridUtil.InitColumnUltraGrid(grid2, "WORKQTY", "작업수량", false, GridColDataType_emu.VarChar, 100, 0, Infragistics.Win.HAlign.Right, false, false,"#,###,###");

                grid2.DisplayLayout.Bands[0].Columns["PLANTCODE"].Header.Appearance.ForeColor = Color.LightSkyBlue;
                grid2.DisplayLayout.Bands[0].Columns["PLANNO"].Header.Appearance.ForeColor = Color.LightSkyBlue;
                grid2.DisplayLayout.Bands[0].Columns["ITEMCODE"].Header.Appearance.ForeColor = Color.LightSkyBlue;
                grid2.DisplayLayout.Bands[0].Columns["PLANQTY"].Header.Appearance.ForeColor = Color.LightSkyBlue;

                _GridUtil.SetInitUltraGridBind(grid2);
                grid2.DisplayLayout.Override.HeaderClickAction = HeaderClickAction.Select;

                #region --- Combobox & Popup Setting ---

                cbo_STARTDATE_H.Value = DateTime.Now.AddDays(-7);
                cbo_ENDDATE_H.Value = DateTime.Now;

                rtnDtTemp = _Common.GET_BM0000_CODE("PLANTCODE"); //사업장
                WIZ.Common.FillComboboxMaster(this.cbo_PLANTCODE_H, rtnDtTemp, rtnDtTemp.Columns["CODE_ID"].ColumnName, rtnDtTemp.Columns["CODE_NAME"].ColumnName, null, null);
                WIZ.UltraGridUtil.SetComboUltraGrid(this.grid1, "PLANTCODE", rtnDtTemp, "CODE_ID", "CODE_NAME");
                WIZ.UltraGridUtil.SetComboUltraGrid(this.grid2, "PLANTCODE", rtnDtTemp, "CODE_ID", "CODE_NAME");
                cbo_PLANTCODE_H.Value = WIZ.LoginInfo.PlantCode;

                //2019.11.20 추가로 함
                rtnDtTemp = _Common.GET_BM0130_CODE("Y");
                UltraGridUtil.SetComboUltraGrid(this.grid1, "UNITCODE", rtnDtTemp, "CODE_ID", "CODE_NAME");
                //UltraGridUtil.SetComboUltraGrid(this.grid2, "UNITCODE", rtnDtTemp, "CODE_ID", "CODE_NAME");
                btbManager.PopUpAdd(txt_ITEMCODE_H, txt_ITEMNAME_H, "BM0010", new object[] { cbo_PLANTCODE_H, "", "Y" });


                bizGridManager = new BizGridManager(grid2);
                bizGridManager.PopUpAdd("ITEMCODE", "ITEMNAME", "BM0010", new string[] { "PLANTCODE", "", "Y" });

                #endregion
            }
            catch (Exception ex)
            {
                this.ShowDialog(ex.ToString(), Forms.DialogForm.DialogType.OK);
            }
        }
        #endregion

        #region < TOOL BAR AREA >
        public override void DoInquire()
        {
            bNew = false;

            DBHelper helper = new DBHelper(false);

            SeqCheck.Clear();
            try
            {
                _GridUtil.Grid_Clear(grid2);
                _GridUtil.Grid_Clear(grid1);

                string sPlantCode = Convert.ToString(cbo_PLANTCODE_H.Value);
                string sSDate = string.Format("{0:yyyy-MM-dd}", cbo_STARTDATE_H.Value);
                string sEDate = string.Format("{0:yyyy-MM-dd}", cbo_ENDDATE_H.Value);
                string sItemCode = txt_ITEMCODE_H.Text.Trim();
                string sItemName = txt_ITEMNAME_H.Text.Trim();

                base.DoInquire();

                dtGrid = helper.FillTable("USP_AP0017_S1", CommandType.StoredProcedure
                       , helper.CreateParameter("AS_PLANTCODE", sPlantCode, DbType.String, ParameterDirection.Input)
                       , helper.CreateParameter("AS_SDATE", sSDate, DbType.String, ParameterDirection.Input)
                       , helper.CreateParameter("AS_EDATE", sEDate, DbType.String, ParameterDirection.Input)
                       , helper.CreateParameter("AS_ITEMCODE", sItemCode, DbType.String, ParameterDirection.Input));
                
                grid2.DataSource = dtGrid;
                grid2.DataBinds(dtGrid);
            }
            catch (Exception ex)
            {
                this.ShowDialog(ex.ToString(), Forms.DialogForm.DialogType.OK);
            }
            finally
            {
                ClosePrgFormNew();

                helper.Close();
            }
        }

        public override void DoNew()
        {
            base.DoNew();

            DBHelper helper = new DBHelper(false);

            try
            {
                this.grid2.InsertRow();

                //사업장과 사용여부는 행 추가시 기본으로 세팅
                this.grid2.ActiveRow.Cells["PLANTCODE"].Value = Convert.ToString(cbo_PLANTCODE_H.Value);
                this.grid2.ActiveRow.Cells["PLANNO"].Value = "자동채번";
                this.grid2.ActiveRow.Cells["RECDATE"].Value = DateTime.Now.ToString("yyyy-MM-dd");
                
                grid2.ActiveRow.Cells["PLANTCODE"].Activation = Activation.NoEdit;
                grid2.ActiveRow.Cells["PLANNO"].Activation = Activation.NoEdit;
                grid2.ActiveRow.Cells["UNITCODE"].Activation = Activation.NoEdit;

                //UltraGridUtil.ActivationAllowEdit(grid2, "ITEMCODE", dtRowNum);

                grid2.ActiveRow.Cells["ITEMCODE"].Activation = Activation.AllowEdit;
                grid2.ActiveRow.Cells["ITEMNAME"].Activation = Activation.AllowEdit;
                grid2.ActiveRow.Cells["PLANQTY"].Activation = Activation.AllowEdit;

            }
            catch (Exception ex)
            {
                this.ShowDialog(ex.Message, Forms.DialogForm.DialogType.OK);
            }
            finally
            {
                helper.Close();
            }
        }

        public override void DoDelete()
        {
            base.DoDelete();

            this.grid2.DeleteRow();
        }

        public override void DoSave()
        {
            DataTable dtChange = grid2.chkChange();

            if (dtChange == null)
                return;

            string sPlantCode = Convert.ToString(cbo_PLANTCODE_H.Value);
            string sPlanNO = string.Empty;
            string sItemCode = string.Empty;
            string sOrderDate = string.Empty;
            string sUser = LoginInfo.UserID;
            string sPlanQty = "0";

            DBHelper helper = new DBHelper("", true);

            try
            {
                base.DoSave();
                foreach (DataRow drChange in dtChange.Rows)
                {
                    if (DBHelper.nvlString(drChange["chk"]) != "")
                    {
                        continue;
                    }

                    switch (drChange.RowState)
                    {
                          
                        case DataRowState.Deleted:
                            drChange.RejectChanges();

                            sPlantCode = Convert.ToString(cbo_PLANTCODE_H.Value);
                            sPlanNO = DBHelper.nvlString(drChange["PLANNO"]);
                            sItemCode = DBHelper.nvlString(drChange["ITEMCODE"]);
                            sOrderDate = Convert.ToString(drChange["RECDATE"]);

                            helper.ExecuteNoneQuery("USP_AP0017_D1", CommandType.StoredProcedure
                            , helper.CreateParameter("AS_PLANTCODE", sPlantCode, DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AS_PLANNO", sPlanNO, DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AS_RECDATE", sOrderDate, DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AS_ITEMCODE", sItemCode, DbType.String, ParameterDirection.Input));
                            break;

                        case DataRowState.Modified:

                            sPlantCode = Convert.ToString(cbo_PLANTCODE_H.Value);
                            sPlanNO = DBHelper.nvlString(drChange["PLANNO"]);
                            sItemCode = DBHelper.nvlString(drChange["ITEMCODE"]);
                            sPlanQty = Convert.ToString(drChange["PLANQTY"]);
                            sOrderDate = Convert.ToString(drChange["RECDATE"]);

                            helper.ExecuteNoneQuery("USP_AP0017_U1", CommandType.StoredProcedure
                            , helper.CreateParameter("AS_PLANTCODE", sPlantCode, DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AS_PLANNO", sPlanNO, DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AS_ITEMCODE", sItemCode, DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AS_RECDATE", sOrderDate, DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AF_PLANQTY", sPlanQty, DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AS_USER", sUser, DbType.String, ParameterDirection.Input));

                            break;

                        case DataRowState.Added:


                            sPlanQty = DBHelper.nvlString(drChange["PLANQTY"]);
                            sPlantCode = Convert.ToString(cbo_PLANTCODE_H.Value);
                            sItemCode = DBHelper.nvlString(drChange["ITEMCODE"]);
                            sOrderDate = DBHelper.nvlString(drChange["RECDATE"]);
                            
                            helper.ExecuteNoneQuery("USP_AP0017_I1", CommandType.StoredProcedure
                            , helper.CreateParameter("AS_PLANTCODE", Convert.ToString(cbo_PLANTCODE_H.Value), DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AS_PLANNO", "", DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AS_ITEMCODE", sItemCode, DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AS_RECDATE", sOrderDate, DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AF_PLANQTY", sPlanQty, DbType.String, ParameterDirection.Input)
                            , helper.CreateParameter("AS_USER", sUser, DbType.String, ParameterDirection.Input));

                            break;
                    }
                    if (helper.RSCODE != "S")
                    {
                        throw new Exception(helper.RSMSG);
                    }
                }

                grid2.SetAcceptChanges();

                helper.Commit();

                DoInquire();
            }
            catch (Exception ex)
            {
                helper.Rollback();

                this.ShowDialog(ex.Message, Forms.DialogForm.DialogType.OK);
            }
            finally
            {
                helper.Close();

                ClosePrgFormNew();
            }
        }
        #endregion

        #region < EVENT AREA >

        private void grid1_ClickCell(object sender, ClickCellEventArgs e)
        {
            if (e.Cell.Row.Index < 0) return;

            DBHelper helper = new DBHelper(false);

            try
            {
                //
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                helper.Close();
                this.ClosePrgFormNew();
            }
        }

        // 전체 선택
        private void BtnCheck_Click(object sender, EventArgs e)
        {   
            for (int iRow = 0; iRow < grid2.Rows.Count; iRow++)
            {
                if (DBHelper.nvlBoolean(grid2.Rows[iRow].Cells["CHK"].Value) == true)
                {
                    grid2.Rows[iRow].Cells["CHK"].Value = false;
                    SeqCheck.Remove(iRow);
                }
                else
                {
                    grid2.Rows[iRow].Cells["CHK"].Value = true;
                    SeqCheck.Add(iRow);
                }

            }
        }

        //전체 선택 추가
        private void BtnCheck_ADD_Click(object sender, EventArgs e)
        {
            base.DoNew();

            DBHelper helper = new DBHelper(false);

            grid2.ActiveRow.Cells["PLANTCODE"].Activation = Activation.NoEdit;
            grid2.ActiveRow.Cells["PLANNO"].Activation = Activation.NoEdit;
            grid2.ActiveRow.Cells["UNITCODE"].Activation = Activation.NoEdit;

            try
            {
                //for (int iRow = 0; iRow < grid2.Rows.Count; iRow++)
                //{
                //    if (DBHelper.nvlBoolean(grid2.Rows[iRow].Cells["CHK"].Value) == true)
                //    {
                //        string sItemCode = DBHelper.nvlString(grid2.Rows[iRow].Cells["ITEMCODE"].Value);
                //        string sItemName = DBHelper.nvlString(grid2.Rows[iRow].Cells["ITEMNAME"].Value);
                //        string sUnitCode = DBHelper.nvlString(grid2.Rows[iRow].Cells["UNITCODE"].Value);

                //        this.grid2.InsertRow();

                //        //사업장과 사용여부는 행 추가시 기본으로 세팅
                //        this.grid2.ActiveRow.Cells["PLANTCODE"].Value = WIZ.LoginInfo.PlantCode;
                //        this.grid2.ActiveRow.Cells["ITEMCODE"].Value = sItemCode;
                //        this.grid2.ActiveRow.Cells["ITEMNAME"].Value = sItemName;
                //        this.grid2.ActiveRow.Cells["UNITCODE"].Value = sUnitCode;                     
                //        this.grid2.ActiveRow.Cells["RECDATE"].Value = DateTime.Now.ToString("yyyy-MM-dd");
                //    }
                //}
                for (int iRow = 0; iRow < SeqCheck.Count; iRow++)
                {
                    int seq = DBHelper.nvlInt(SeqCheck[iRow]);
                    string sItemCode = DBHelper.nvlString(grid2.Rows[seq].Cells["ITEMCODE"].Value);
                    string sItemName = DBHelper.nvlString(grid2.Rows[seq].Cells["ITEMNAME"].Value);
                    string sUnitCode = DBHelper.nvlString(grid2.Rows[seq].Cells["UNITCODE"].Value);
                    string sPlanQty = DBHelper.nvlString(grid2.Rows[seq].Cells["PLANQTY"].Value);

                    this.grid2.InsertRow();

                    //사업장과 사용여부는 행 추가시 기본으로 세팅
                    this.grid2.ActiveRow.Cells["PLANTCODE"].Value = Convert.ToString(cbo_PLANTCODE_H.Value);
                    this.grid2.ActiveRow.Cells["PLANNO"].Value = "자동채번";
                    this.grid2.ActiveRow.Cells["ITEMCODE"].Value = sItemCode;
                    this.grid2.ActiveRow.Cells["ITEMNAME"].Value = sItemName;
                    this.grid2.ActiveRow.Cells["UNITCODE"].Value = sUnitCode;
                    this.grid2.ActiveRow.Cells["PLANQTY"].Value = sPlanQty;
                    this.grid2.ActiveRow.Cells["RECDATE"].Value = DateTime.Now.ToString("yyyy-MM-dd");
                }

            }
            catch (Exception ex)
            {
                this.ShowDialog(ex.Message, Forms.DialogForm.DialogType.OK);
            }
            finally
            {
                helper.Close();
            }
        }

        private void grid2_ClickCell(object sender, ClickCellEventArgs e)
        {
            if (((WIZ.Control.Grid)(sender)).ActiveCell.Column.Key == "CHK")
            {
                bool chk = Convert.ToString(this.grid2.Rows[this.grid2.ActiveRow.Index].Cells["CHK"].Value).ToUpper() == "1" ? true : false;

                if (chk == true)
                {
                    this.grid2.Rows[this.grid2.ActiveRow.Index].Cells["CHK"].Value = false;
                    SeqCheck.Remove(this.grid2.ActiveRow.Index);
                }
                else
                {
                    this.grid2.Rows[this.grid2.ActiveRow.Index].Cells["CHK"].Value = true;
                    SeqCheck.Add(this.grid2.ActiveRow.Index);
                }
            }
        }

        #endregion

        #region < METHOD AREA >

        #endregion


    }//CLASS
}//NAMESPACE
