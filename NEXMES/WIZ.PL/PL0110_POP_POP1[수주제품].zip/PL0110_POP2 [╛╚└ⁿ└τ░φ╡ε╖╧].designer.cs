namespace WIZ.PL
{
    partial class PL0110_POP2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance46 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            this.ultraGroupBox2 = new Infragistics.Win.Misc.UltraGroupBox();
            this.txtCUSTNAME = new WIZ.Control.STextBox(this.components);
            this.txtCUSTCODE = new WIZ.Control.SBtnTextEditor();
            this.txtTYPE = new WIZ.Control.STextBox(this.components);
            this.sLabel2 = new WIZ.Control.SLabel();
            this.sLabel16 = new WIZ.Control.SLabel();
            this.txtTOTALCOST = new WIZ.Control.STextBox(this.components);
            this.sLabel15 = new WIZ.Control.SLabel();
            this.BtnProd = new System.Windows.Forms.Button();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.sLabel14 = new WIZ.Control.SLabel();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.btnSAVE = new Infragistics.Win.Misc.UltraButton();
            this.txtETC = new WIZ.Control.STextBox(this.components);
            this.sLabel4 = new WIZ.Control.SLabel();
            this.txtCOST = new WIZ.Control.STextBox(this.components);
            this.sLabel3 = new WIZ.Control.SLabel();
            this.txtCNT = new WIZ.Control.STextBox(this.components);
            this.sLabel1 = new WIZ.Control.SLabel();
            this.sLabel5 = new WIZ.Control.SLabel();
            this.txtPARTNAME = new WIZ.Control.STextBox(this.components);
            this.sLabel9 = new WIZ.Control.SLabel();
            ((System.ComponentModel.ISupportInitialize)(this.gbxHeader)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gbxBody)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox2)).BeginInit();
            this.ultraGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCUSTNAME)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCUSTCODE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTYPE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTOTALCOST)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtETC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCOST)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCNT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPARTNAME)).BeginInit();
            this.SuspendLayout();
            // 
            // gbxHeader
            // 
            this.gbxHeader.ContentPadding.Bottom = 2;
            this.gbxHeader.ContentPadding.Left = 2;
            this.gbxHeader.ContentPadding.Right = 2;
            this.gbxHeader.ContentPadding.Top = 4;
            this.gbxHeader.Dock = System.Windows.Forms.DockStyle.None;
            this.gbxHeader.Location = new System.Drawing.Point(879, 52);
            this.gbxHeader.Size = new System.Drawing.Size(170, 217);
            this.gbxHeader.Visible = false;
            // 
            // gbxBody
            // 
            this.gbxBody.AllowDrop = true;
            this.gbxBody.ContentPadding.Bottom = 2;
            this.gbxBody.ContentPadding.Left = 2;
            this.gbxBody.ContentPadding.Right = 2;
            this.gbxBody.ContentPadding.Top = 4;
            this.gbxBody.Dock = System.Windows.Forms.DockStyle.None;
            this.gbxBody.Location = new System.Drawing.Point(0, 11);
            this.gbxBody.Size = new System.Drawing.Size(565, 411);
            // 
            // ultraGroupBox2
            // 
            this.ultraGroupBox2.AllowDrop = true;
            this.ultraGroupBox2.Controls.Add(this.txtCUSTNAME);
            this.ultraGroupBox2.Controls.Add(this.txtCUSTCODE);
            this.ultraGroupBox2.Controls.Add(this.txtTYPE);
            this.ultraGroupBox2.Controls.Add(this.sLabel2);
            this.ultraGroupBox2.Controls.Add(this.sLabel16);
            this.ultraGroupBox2.Controls.Add(this.txtTOTALCOST);
            this.ultraGroupBox2.Controls.Add(this.sLabel15);
            this.ultraGroupBox2.Controls.Add(this.BtnProd);
            this.ultraGroupBox2.Controls.Add(this.dateTimePicker3);
            this.ultraGroupBox2.Controls.Add(this.sLabel14);
            this.ultraGroupBox2.Controls.Add(this.dateTimePicker2);
            this.ultraGroupBox2.Controls.Add(this.btnSAVE);
            this.ultraGroupBox2.Controls.Add(this.txtETC);
            this.ultraGroupBox2.Controls.Add(this.sLabel4);
            this.ultraGroupBox2.Controls.Add(this.txtCOST);
            this.ultraGroupBox2.Controls.Add(this.sLabel3);
            this.ultraGroupBox2.Controls.Add(this.txtCNT);
            this.ultraGroupBox2.Controls.Add(this.sLabel1);
            this.ultraGroupBox2.Controls.Add(this.sLabel5);
            this.ultraGroupBox2.Controls.Add(this.txtPARTNAME);
            this.ultraGroupBox2.Controls.Add(this.sLabel9);
            this.ultraGroupBox2.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ultraGroupBox2.Location = new System.Drawing.Point(4, 9);
            this.ultraGroupBox2.Margin = new System.Windows.Forms.Padding(0);
            this.ultraGroupBox2.Name = "ultraGroupBox2";
            this.ultraGroupBox2.Size = new System.Drawing.Size(557, 407);
            this.ultraGroupBox2.TabIndex = 4;
            this.ultraGroupBox2.Text = "������� ��ϳ���";
            // 
            // txtCUSTNAME
            // 
            appearance46.FontData.BoldAsString = "False";
            appearance46.FontData.UnderlineAsString = "False";
            appearance46.ForeColor = System.Drawing.Color.Black;
            this.txtCUSTNAME.Appearance = appearance46;
            this.txtCUSTNAME.AutoSize = false;
            this.txtCUSTNAME.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtCUSTNAME.Location = new System.Drawing.Point(207, 37);
            this.txtCUSTNAME.Name = "txtCUSTNAME";
            this.txtCUSTNAME.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtCUSTNAME.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtCUSTNAME.Size = new System.Drawing.Size(125, 27);
            this.txtCUSTNAME.TabIndex = 1130;
            // 
            // txtCUSTCODE
            // 
            appearance24.FontData.BoldAsString = "False";
            appearance24.FontData.Name = "���� ����";
            appearance24.FontData.SizeInPoints = 10F;
            appearance24.FontData.UnderlineAsString = "False";
            appearance24.ForeColor = System.Drawing.Color.Black;
            this.txtCUSTCODE.Appearance = appearance24;
            this.txtCUSTCODE.AutoSize = false;
            this.txtCUSTCODE.btnImgType = WIZ.Control.SBtnTextEditor.ButtonImgTypeEnum.Type1;
            this.txtCUSTCODE.btnWidth = 26;
            this.txtCUSTCODE.Location = new System.Drawing.Point(103, 37);
            this.txtCUSTCODE.Name = "txtCUSTCODE";
            this.txtCUSTCODE.RequireFlag = WIZ.Control.SBtnTextEditor.RequireFlagEnum.NO;
            this.txtCUSTCODE.RequirePop = WIZ.Control.SBtnTextEditor.RequireFlagEnum.NO;
            this.txtCUSTCODE.Size = new System.Drawing.Size(105, 27);
            this.txtCUSTCODE.TabIndex = 1129;
            // 
            // txtTYPE
            // 
            appearance21.FontData.BoldAsString = "False";
            appearance21.FontData.UnderlineAsString = "False";
            appearance21.ForeColor = System.Drawing.Color.Black;
            this.txtTYPE.Appearance = appearance21;
            this.txtTYPE.AutoSize = false;
            this.txtTYPE.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtTYPE.Location = new System.Drawing.Point(374, 117);
            this.txtTYPE.Name = "txtTYPE";
            this.txtTYPE.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtTYPE.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtTYPE.Size = new System.Drawing.Size(163, 27);
            this.txtTYPE.TabIndex = 1127;
            // 
            // sLabel2
            // 
            appearance22.BackColor = System.Drawing.Color.Transparent;
            appearance22.FontData.BoldAsString = "False";
            appearance22.FontData.UnderlineAsString = "False";
            appearance22.ForeColor = System.Drawing.Color.Black;
            appearance22.TextHAlignAsString = "Left";
            appearance22.TextVAlignAsString = "Middle";
            this.sLabel2.Appearance = appearance22;
            this.sLabel2.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel2.DbField = null;
            this.sLabel2.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel2.Location = new System.Drawing.Point(297, 117);
            this.sLabel2.Name = "sLabel2";
            this.sLabel2.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel2.Size = new System.Drawing.Size(74, 25);
            this.sLabel2.TabIndex = 1128;
            this.sLabel2.Text = "����";
            // 
            // sLabel16
            // 
            appearance25.BackColor = System.Drawing.Color.Transparent;
            appearance25.FontData.BoldAsString = "False";
            appearance25.FontData.UnderlineAsString = "False";
            appearance25.ForeColor = System.Drawing.Color.Black;
            appearance25.TextHAlignAsString = "Left";
            appearance25.TextVAlignAsString = "Middle";
            this.sLabel16.Appearance = appearance25;
            this.sLabel16.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel16.DbField = null;
            this.sLabel16.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel16.Location = new System.Drawing.Point(297, 222);
            this.sLabel16.Name = "sLabel16";
            this.sLabel16.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel16.Size = new System.Drawing.Size(74, 25);
            this.sLabel16.TabIndex = 1126;
            this.sLabel16.Text = "�� �ݾ�";
            // 
            // txtTOTALCOST
            // 
            appearance1.FontData.BoldAsString = "False";
            appearance1.FontData.UnderlineAsString = "False";
            appearance1.ForeColor = System.Drawing.Color.Black;
            this.txtTOTALCOST.Appearance = appearance1;
            this.txtTOTALCOST.AutoSize = false;
            this.txtTOTALCOST.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtTOTALCOST.Location = new System.Drawing.Point(374, 222);
            this.txtTOTALCOST.Name = "txtTOTALCOST";
            this.txtTOTALCOST.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtTOTALCOST.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtTOTALCOST.Size = new System.Drawing.Size(163, 27);
            this.txtTOTALCOST.TabIndex = 1125;
            this.txtTOTALCOST.Text = "0";
            // 
            // sLabel15
            // 
            appearance19.BackColor = System.Drawing.Color.Transparent;
            appearance19.FontData.BoldAsString = "False";
            appearance19.FontData.UnderlineAsString = "False";
            appearance19.ForeColor = System.Drawing.Color.Black;
            appearance19.TextHAlignAsString = "Left";
            appearance19.TextVAlignAsString = "Middle";
            this.sLabel15.Appearance = appearance19;
            this.sLabel15.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel15.DbField = null;
            this.sLabel15.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel15.Location = new System.Drawing.Point(25, 222);
            this.sLabel15.Name = "sLabel15";
            this.sLabel15.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel15.Size = new System.Drawing.Size(74, 25);
            this.sLabel15.TabIndex = 1124;
            this.sLabel15.Text = "�ܰ�";
            // 
            // BtnProd
            // 
            this.BtnProd.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BtnProd.Location = new System.Drawing.Point(497, 84);
            this.BtnProd.Margin = new System.Windows.Forms.Padding(0);
            this.BtnProd.Name = "BtnProd";
            this.BtnProd.Size = new System.Drawing.Size(40, 27);
            this.BtnProd.TabIndex = 1122;
            this.BtnProd.Text = "��";
            this.BtnProd.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnProd.UseVisualStyleBackColor = true;
            this.BtnProd.Click += new System.EventHandler(this.BtnProd_Click);
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker3.Location = new System.Drawing.Point(374, 173);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(163, 25);
            this.dateTimePicker3.TabIndex = 744;
            // 
            // sLabel14
            // 
            appearance20.BackColor = System.Drawing.Color.Transparent;
            appearance20.FontData.BoldAsString = "False";
            appearance20.FontData.UnderlineAsString = "False";
            appearance20.ForeColor = System.Drawing.Color.Black;
            appearance20.TextHAlignAsString = "Left";
            appearance20.TextVAlignAsString = "Middle";
            this.sLabel14.Appearance = appearance20;
            this.sLabel14.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel14.DbField = null;
            this.sLabel14.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel14.Location = new System.Drawing.Point(297, 173);
            this.sLabel14.Name = "sLabel14";
            this.sLabel14.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel14.Size = new System.Drawing.Size(74, 25);
            this.sLabel14.TabIndex = 743;
            this.sLabel14.Text = "������";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(102, 173);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(163, 25);
            this.dateTimePicker2.TabIndex = 742;
            // 
            // btnSAVE
            // 
            this.btnSAVE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSAVE.Font = new System.Drawing.Font("���� ����", 9F, System.Drawing.FontStyle.Bold);
            this.btnSAVE.Location = new System.Drawing.Point(445, 367);
            this.btnSAVE.Margin = new System.Windows.Forms.Padding(0);
            this.btnSAVE.Name = "btnSAVE";
            this.btnSAVE.Size = new System.Drawing.Size(96, 27);
            this.btnSAVE.TabIndex = 738;
            this.btnSAVE.Text = "���";
            this.btnSAVE.Click += new System.EventHandler(this.btnSAVE_Click);
            // 
            // txtETC
            // 
            appearance16.FontData.BoldAsString = "False";
            appearance16.FontData.UnderlineAsString = "False";
            appearance16.ForeColor = System.Drawing.Color.Black;
            this.txtETC.Appearance = appearance16;
            this.txtETC.AutoSize = false;
            this.txtETC.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtETC.Location = new System.Drawing.Point(102, 276);
            this.txtETC.Multiline = true;
            this.txtETC.Name = "txtETC";
            this.txtETC.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtETC.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtETC.Size = new System.Drawing.Size(435, 78);
            this.txtETC.TabIndex = 722;
            // 
            // sLabel4
            // 
            appearance18.BackColor = System.Drawing.Color.Transparent;
            appearance18.FontData.BoldAsString = "False";
            appearance18.FontData.UnderlineAsString = "False";
            appearance18.ForeColor = System.Drawing.Color.Black;
            appearance18.TextHAlignAsString = "Left";
            appearance18.TextVAlignAsString = "Middle";
            this.sLabel4.Appearance = appearance18;
            this.sLabel4.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel4.DbField = null;
            this.sLabel4.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel4.Location = new System.Drawing.Point(25, 276);
            this.sLabel4.Name = "sLabel4";
            this.sLabel4.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel4.Size = new System.Drawing.Size(233, 25);
            this.sLabel4.TabIndex = 723;
            this.sLabel4.Text = "����";
            // 
            // txtCOST
            // 
            appearance26.FontData.BoldAsString = "False";
            appearance26.FontData.UnderlineAsString = "False";
            appearance26.ForeColor = System.Drawing.Color.Black;
            this.txtCOST.Appearance = appearance26;
            this.txtCOST.AutoSize = false;
            this.txtCOST.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtCOST.Location = new System.Drawing.Point(102, 222);
            this.txtCOST.Name = "txtCOST";
            this.txtCOST.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtCOST.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtCOST.Size = new System.Drawing.Size(163, 27);
            this.txtCOST.TabIndex = 720;
            this.txtCOST.Text = "0";
            this.txtCOST.TextChanged += new System.EventHandler(this.txtCOST_TextChanged);
            // 
            // sLabel3
            // 
            appearance27.BackColor = System.Drawing.Color.Transparent;
            appearance27.FontData.BoldAsString = "False";
            appearance27.FontData.UnderlineAsString = "False";
            appearance27.ForeColor = System.Drawing.Color.Black;
            appearance27.TextHAlignAsString = "Left";
            appearance27.TextVAlignAsString = "Middle";
            this.sLabel3.Appearance = appearance27;
            this.sLabel3.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel3.DbField = null;
            this.sLabel3.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel3.Location = new System.Drawing.Point(25, 173);
            this.sLabel3.Name = "sLabel3";
            this.sLabel3.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel3.Size = new System.Drawing.Size(74, 25);
            this.sLabel3.TabIndex = 719;
            this.sLabel3.Text = "������";
            // 
            // txtCNT
            // 
            appearance2.FontData.BoldAsString = "False";
            appearance2.FontData.UnderlineAsString = "False";
            appearance2.ForeColor = System.Drawing.Color.Black;
            this.txtCNT.Appearance = appearance2;
            this.txtCNT.AutoSize = false;
            this.txtCNT.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtCNT.Location = new System.Drawing.Point(102, 117);
            this.txtCNT.Name = "txtCNT";
            this.txtCNT.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtCNT.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtCNT.Size = new System.Drawing.Size(163, 27);
            this.txtCNT.TabIndex = 716;
            this.txtCNT.Text = "0";
            this.txtCNT.TextChanged += new System.EventHandler(this.txtCNT_TextChanged);
            // 
            // sLabel1
            // 
            appearance4.BackColor = System.Drawing.Color.Transparent;
            appearance4.FontData.BoldAsString = "False";
            appearance4.FontData.UnderlineAsString = "False";
            appearance4.ForeColor = System.Drawing.Color.Black;
            appearance4.TextHAlignAsString = "Left";
            appearance4.TextVAlignAsString = "Middle";
            this.sLabel1.Appearance = appearance4;
            this.sLabel1.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel1.DbField = null;
            this.sLabel1.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel1.Location = new System.Drawing.Point(25, 117);
            this.sLabel1.Name = "sLabel1";
            this.sLabel1.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel1.Size = new System.Drawing.Size(74, 25);
            this.sLabel1.TabIndex = 717;
            this.sLabel1.Text = "����";
            // 
            // sLabel5
            // 
            appearance3.BackColor = System.Drawing.Color.Transparent;
            appearance3.FontData.BoldAsString = "False";
            appearance3.FontData.UnderlineAsString = "False";
            appearance3.ForeColor = System.Drawing.Color.Black;
            appearance3.TextHAlignAsString = "Left";
            appearance3.TextVAlignAsString = "Middle";
            this.sLabel5.Appearance = appearance3;
            this.sLabel5.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel5.DbField = null;
            this.sLabel5.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel5.Location = new System.Drawing.Point(25, 37);
            this.sLabel5.Name = "sLabel5";
            this.sLabel5.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel5.Size = new System.Drawing.Size(74, 25);
            this.sLabel5.TabIndex = 710;
            this.sLabel5.Text = "������";
            // 
            // txtPARTNAME
            // 
            appearance23.FontData.BoldAsString = "False";
            appearance23.FontData.UnderlineAsString = "False";
            appearance23.ForeColor = System.Drawing.Color.Black;
            this.txtPARTNAME.Appearance = appearance23;
            this.txtPARTNAME.AutoSize = false;
            this.txtPARTNAME.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtPARTNAME.Location = new System.Drawing.Point(102, 84);
            this.txtPARTNAME.Name = "txtPARTNAME";
            this.txtPARTNAME.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtPARTNAME.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtPARTNAME.Size = new System.Drawing.Size(392, 27);
            this.txtPARTNAME.TabIndex = 56;
            // 
            // sLabel9
            // 
            appearance5.BackColor = System.Drawing.Color.Transparent;
            appearance5.FontData.BoldAsString = "False";
            appearance5.FontData.UnderlineAsString = "False";
            appearance5.ForeColor = System.Drawing.Color.Black;
            appearance5.TextHAlignAsString = "Left";
            appearance5.TextVAlignAsString = "Middle";
            this.sLabel9.Appearance = appearance5;
            this.sLabel9.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel9.DbField = null;
            this.sLabel9.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel9.Location = new System.Drawing.Point(25, 86);
            this.sLabel9.Name = "sLabel9";
            this.sLabel9.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel9.Size = new System.Drawing.Size(74, 25);
            this.sLabel9.TabIndex = 245;
            this.sLabel9.Text = "ǰ���";
            // 
            // PL0110_POP2
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(567, 424);
            this.Controls.Add(this.ultraGroupBox2);
            this.Name = "PL0110_POP2";
            this.Text = "����������";
            this.Load += new System.EventHandler(this.OD0000_POP_Load);
            this.Controls.SetChildIndex(this.gbxHeader, 0);
            this.Controls.SetChildIndex(this.gbxBody, 0);
            this.Controls.SetChildIndex(this.ultraGroupBox2, 0);
            ((System.ComponentModel.ISupportInitialize)(this.gbxHeader)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gbxBody)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox2)).EndInit();
            this.ultraGroupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtCUSTNAME)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCUSTCODE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTYPE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTOTALCOST)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtETC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCOST)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCNT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPARTNAME)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox2;
        private Control.STextBox txtPARTNAME;
        private Control.SLabel sLabel9;
        private Control.SLabel sLabel5;
        private Control.STextBox txtETC;
        private Control.SLabel sLabel4;
        private Control.STextBox txtCOST;
        private Control.SLabel sLabel3;
        private Control.STextBox txtCNT;
        private Control.SLabel sLabel1;
        private Infragistics.Win.Misc.UltraButton btnSAVE;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private Control.SLabel sLabel14;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private Control.SLabel sLabel16;
        private Control.STextBox txtTOTALCOST;
        private Control.SLabel sLabel15;
        private System.Windows.Forms.Button BtnProd;
        private Control.STextBox txtTYPE;
        private Control.SLabel sLabel2;
        private Control.STextBox txtCUSTNAME;
        private Control.SBtnTextEditor txtCUSTCODE;
    }
}