namespace WIZ.PL
{
    partial class PL0110_POP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Infragistics.Win.Appearance appearance73 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance74 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance75 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance76 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance77 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance78 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance79 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance80 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance81 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance82 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance83 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance84 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance5 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance6 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance7 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance8 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance9 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance10 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance11 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance12 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance13 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance14 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance15 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance16 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance49 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance50 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance51 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance52 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance53 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance54 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance55 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance56 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance57 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance58 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance59 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance60 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance18 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance19 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance20 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance21 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance23 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance25 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance26 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance27 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance28 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance29 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance30 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance31 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance47 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance1 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance24 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance4 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance32 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance22 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance48 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance61 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance33 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance34 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance3 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance2 = new Infragistics.Win.Appearance();
            Infragistics.Win.Appearance appearance17 = new Infragistics.Win.Appearance();
            this.txtREPAIRCODE = new System.Windows.Forms.TextBox();
            this.ultraGroupBox2 = new Infragistics.Win.Misc.UltraGroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btn_INSERTROW = new Infragistics.Win.Misc.UltraButton();
            this.ultraButton3 = new Infragistics.Win.Misc.UltraButton();
            this.chk_DAY = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.grid4 = new WIZ.Control.Grid(this.components);
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.grid2 = new WIZ.Control.Grid(this.components);
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.grid5 = new WIZ.Control.Grid(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.grid1 = new WIZ.Control.Grid(this.components);
            this.cbo_GUBUN = new Infragistics.Win.UltraWinEditors.UltraComboEditor();
            this.sLabel2 = new WIZ.Control.SLabel();
            this.btnSave = new Infragistics.Win.Misc.UltraButton();
            this.txtCYCLETIME = new WIZ.Control.STextBox(this.components);
            this.sLabel19 = new WIZ.Control.SLabel();
            this.dtp_STARTDATE = new System.Windows.Forms.DateTimePicker();
            this.sLabel14 = new WIZ.Control.SLabel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtRECENTHO = new WIZ.Control.STextBox(this.components);
            this.txtDATE = new WIZ.Control.STextBox(this.components);
            this.sLabel10 = new WIZ.Control.SLabel();
            this.sLabel8 = new WIZ.Control.SLabel();
            this.txtVEND = new WIZ.Control.STextBox(this.components);
            this.sLabel6 = new WIZ.Control.SLabel();
            this.txtBARCODE = new System.Windows.Forms.TextBox();
            this.sLabel5 = new WIZ.Control.SLabel();
            this.txtPROD = new WIZ.Control.STextBox(this.components);
            this.sLabel1 = new WIZ.Control.SLabel();
            ((System.ComponentModel.ISupportInitialize)(this.gbxHeader)).BeginInit();
            this.gbxHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gbxBody)).BeginInit();
            this.gbxBody.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox2)).BeginInit();
            this.ultraGroupBox2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid4)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid2)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid5)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbo_GUBUN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCYCLETIME)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtRECENTHO)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDATE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVEND)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPROD)).BeginInit();
            this.SuspendLayout();
            // 
            // gbxHeader
            // 
            this.gbxHeader.ContentPadding.Bottom = 2;
            this.gbxHeader.ContentPadding.Left = 2;
            this.gbxHeader.ContentPadding.Right = 2;
            this.gbxHeader.ContentPadding.Top = 4;
            this.gbxHeader.Controls.Add(this.txtREPAIRCODE);
            this.gbxHeader.Dock = System.Windows.Forms.DockStyle.None;
            this.gbxHeader.Size = new System.Drawing.Size(1252, 43);
            this.gbxHeader.Controls.SetChildIndex(this.txtREPAIRCODE, 0);
            // 
            // gbxBody
            // 
            this.gbxBody.AllowDrop = true;
            this.gbxBody.ContentPadding.Bottom = 2;
            this.gbxBody.ContentPadding.Left = 2;
            this.gbxBody.ContentPadding.Right = 2;
            this.gbxBody.ContentPadding.Top = 4;
            this.gbxBody.Controls.Add(this.ultraGroupBox2);
            this.gbxBody.Location = new System.Drawing.Point(0, 0);
            this.gbxBody.Size = new System.Drawing.Size(1889, 988);
            // 
            // txtREPAIRCODE
            // 
            this.txtREPAIRCODE.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtREPAIRCODE.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtREPAIRCODE.Font = new System.Drawing.Font("���� ����", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtREPAIRCODE.Location = new System.Drawing.Point(568, 23);
            this.txtREPAIRCODE.Name = "txtREPAIRCODE";
            this.txtREPAIRCODE.Size = new System.Drawing.Size(425, 36);
            this.txtREPAIRCODE.TabIndex = 257;
            this.txtREPAIRCODE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtREPAIRCODE.Visible = false;
            // 
            // ultraGroupBox2
            // 
            this.ultraGroupBox2.AllowDrop = true;
            this.ultraGroupBox2.Controls.Add(this.groupBox7);
            this.ultraGroupBox2.Controls.Add(this.chk_DAY);
            this.ultraGroupBox2.Controls.Add(this.groupBox6);
            this.ultraGroupBox2.Controls.Add(this.groupBox4);
            this.ultraGroupBox2.Controls.Add(this.groupBox5);
            this.ultraGroupBox2.Controls.Add(this.groupBox3);
            this.ultraGroupBox2.Controls.Add(this.cbo_GUBUN);
            this.ultraGroupBox2.Controls.Add(this.sLabel2);
            this.ultraGroupBox2.Controls.Add(this.btnSave);
            this.ultraGroupBox2.Controls.Add(this.txtCYCLETIME);
            this.ultraGroupBox2.Controls.Add(this.sLabel19);
            this.ultraGroupBox2.Controls.Add(this.dtp_STARTDATE);
            this.ultraGroupBox2.Controls.Add(this.sLabel14);
            this.ultraGroupBox2.Controls.Add(this.groupBox1);
            this.ultraGroupBox2.Controls.Add(this.txtVEND);
            this.ultraGroupBox2.Controls.Add(this.sLabel6);
            this.ultraGroupBox2.Controls.Add(this.txtBARCODE);
            this.ultraGroupBox2.Controls.Add(this.sLabel5);
            this.ultraGroupBox2.Controls.Add(this.txtPROD);
            this.ultraGroupBox2.Controls.Add(this.sLabel1);
            this.ultraGroupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ultraGroupBox2.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ultraGroupBox2.Location = new System.Drawing.Point(4, 4);
            this.ultraGroupBox2.Margin = new System.Windows.Forms.Padding(0);
            this.ultraGroupBox2.Name = "ultraGroupBox2";
            this.ultraGroupBox2.Size = new System.Drawing.Size(1881, 980);
            this.ultraGroupBox2.TabIndex = 4;
            this.ultraGroupBox2.Text = "��ȹ";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btn_INSERTROW);
            this.groupBox7.Controls.Add(this.ultraButton3);
            this.groupBox7.Location = new System.Drawing.Point(1011, 26);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(258, 68);
            this.groupBox7.TabIndex = 740;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "�߰���� ";
            // 
            // btn_INSERTROW
            // 
            this.btn_INSERTROW.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_INSERTROW.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Bold);
            this.btn_INSERTROW.Location = new System.Drawing.Point(13, 27);
            this.btn_INSERTROW.Margin = new System.Windows.Forms.Padding(0);
            this.btn_INSERTROW.Name = "btn_INSERTROW";
            this.btn_INSERTROW.Size = new System.Drawing.Size(82, 29);
            this.btn_INSERTROW.TabIndex = 760;
            this.btn_INSERTROW.Text = "�� �߰�";
            this.btn_INSERTROW.Click += new System.EventHandler(this.btn_INSERTROW_Click);
            // 
            // ultraButton3
            // 
            this.ultraButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ultraButton3.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Bold);
            this.ultraButton3.Location = new System.Drawing.Point(111, 26);
            this.ultraButton3.Margin = new System.Windows.Forms.Padding(0);
            this.ultraButton3.Name = "ultraButton3";
            this.ultraButton3.Size = new System.Drawing.Size(129, 29);
            this.ultraButton3.TabIndex = 761;
            this.ultraButton3.Text = "������� �߰�";
            this.ultraButton3.Click += new System.EventHandler(this.ultraButton3_Click);
            // 
            // chk_DAY
            // 
            this.chk_DAY.AutoSize = true;
            this.chk_DAY.Location = new System.Drawing.Point(918, 31);
            this.chk_DAY.Name = "chk_DAY";
            this.chk_DAY.Size = new System.Drawing.Size(79, 21);
            this.chk_DAY.TabIndex = 759;
            this.chk_DAY.Text = "������ȸ";
            this.chk_DAY.UseVisualStyleBackColor = true;
            this.chk_DAY.CheckedChanged += new System.EventHandler(this.chk_DAY_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.grid4);
            this.groupBox6.Location = new System.Drawing.Point(827, 107);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1046, 436);
            this.groupBox6.TabIndex = 758;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "�ְ���ȹ";
            // 
            // grid4
            // 
            this.grid4.AutoResizeColumn = true;
            this.grid4.AutoUserColumn = true;
            this.grid4.ContextMenuCopyEnabled = true;
            this.grid4.ContextMenuDeleteEnabled = true;
            this.grid4.ContextMenuExcelEnabled = true;
            this.grid4.ContextMenuInsertEnabled = true;
            this.grid4.ContextMenuPasteEnabled = true;
            this.grid4.DeleteButtonEnable = true;
            appearance73.BackColor = System.Drawing.SystemColors.Window;
            appearance73.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grid4.DisplayLayout.Appearance = appearance73;
            this.grid4.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grid4.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            this.grid4.DisplayLayout.DefaultSelectedBackColor = System.Drawing.Color.Empty;
            appearance74.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance74.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance74.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance74.BorderColor = System.Drawing.SystemColors.Window;
            this.grid4.DisplayLayout.GroupByBox.Appearance = appearance74;
            appearance75.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid4.DisplayLayout.GroupByBox.BandLabelAppearance = appearance75;
            this.grid4.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grid4.DisplayLayout.GroupByBox.Hidden = true;
            appearance76.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance76.BackColor2 = System.Drawing.SystemColors.Control;
            appearance76.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance76.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid4.DisplayLayout.GroupByBox.PromptAppearance = appearance76;
            this.grid4.DisplayLayout.MaxColScrollRegions = 1;
            this.grid4.DisplayLayout.MaxRowScrollRegions = 1;
            appearance77.BackColor = System.Drawing.SystemColors.Window;
            appearance77.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grid4.DisplayLayout.Override.ActiveCellAppearance = appearance77;
            appearance78.BackColor = System.Drawing.SystemColors.Highlight;
            appearance78.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grid4.DisplayLayout.Override.ActiveRowAppearance = appearance78;
            this.grid4.DisplayLayout.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.True;
            this.grid4.DisplayLayout.Override.AllowMultiCellOperations = ((Infragistics.Win.UltraWinGrid.AllowMultiCellOperation)((((((((Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Copy | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.CopyWithHeaders) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Cut) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Delete) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Paste) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Undo) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Redo) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Reserved)));
            this.grid4.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grid4.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance79.BackColor = System.Drawing.SystemColors.Window;
            this.grid4.DisplayLayout.Override.CardAreaAppearance = appearance79;
            appearance80.BorderColor = System.Drawing.Color.Silver;
            appearance80.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grid4.DisplayLayout.Override.CellAppearance = appearance80;
            this.grid4.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grid4.DisplayLayout.Override.CellPadding = 0;
            appearance81.BackColor = System.Drawing.SystemColors.Control;
            appearance81.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance81.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance81.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance81.BorderColor = System.Drawing.SystemColors.Window;
            this.grid4.DisplayLayout.Override.GroupByRowAppearance = appearance81;
            appearance82.TextHAlignAsString = "Left";
            this.grid4.DisplayLayout.Override.HeaderAppearance = appearance82;
            this.grid4.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grid4.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance83.BackColor = System.Drawing.SystemColors.Window;
            appearance83.BorderColor = System.Drawing.Color.Silver;
            this.grid4.DisplayLayout.Override.RowAppearance = appearance83;
            this.grid4.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance84.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grid4.DisplayLayout.Override.TemplateAddRowAppearance = appearance84;
            this.grid4.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grid4.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grid4.DisplayLayout.SelectionOverlayBorderThickness = 2;
            this.grid4.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grid4.EnterNextRowEnable = true;
            this.grid4.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.grid4.Location = new System.Drawing.Point(6, 17);
            this.grid4.Name = "grid4";
            this.grid4.Size = new System.Drawing.Size(1034, 413);
            this.grid4.TabIndex = 756;
            this.grid4.Text = "grid5";
            this.grid4.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.grid4.UpdateMode = Infragistics.Win.UltraWinGrid.UpdateMode.OnCellChange;
            this.grid4.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.grid4.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.grid4.InitializeLayout += new Infragistics.Win.UltraWinGrid.InitializeLayoutEventHandler(this.grid5_InitializeLayout);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.grid2);
            this.groupBox4.Location = new System.Drawing.Point(8, 549);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(813, 419);
            this.groupBox4.TabIndex = 758;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "������";
            // 
            // grid2
            // 
            this.grid2.AutoResizeColumn = true;
            this.grid2.AutoUserColumn = true;
            this.grid2.ContextMenuCopyEnabled = true;
            this.grid2.ContextMenuDeleteEnabled = true;
            this.grid2.ContextMenuExcelEnabled = true;
            this.grid2.ContextMenuInsertEnabled = true;
            this.grid2.ContextMenuPasteEnabled = true;
            this.grid2.DeleteButtonEnable = true;
            appearance5.BackColor = System.Drawing.SystemColors.Window;
            appearance5.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grid2.DisplayLayout.Appearance = appearance5;
            this.grid2.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grid2.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            this.grid2.DisplayLayout.DefaultSelectedBackColor = System.Drawing.Color.Empty;
            appearance6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance6.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance6.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance6.BorderColor = System.Drawing.SystemColors.Window;
            this.grid2.DisplayLayout.GroupByBox.Appearance = appearance6;
            appearance7.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid2.DisplayLayout.GroupByBox.BandLabelAppearance = appearance7;
            this.grid2.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grid2.DisplayLayout.GroupByBox.Hidden = true;
            appearance8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance8.BackColor2 = System.Drawing.SystemColors.Control;
            appearance8.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance8.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid2.DisplayLayout.GroupByBox.PromptAppearance = appearance8;
            this.grid2.DisplayLayout.MaxColScrollRegions = 1;
            this.grid2.DisplayLayout.MaxRowScrollRegions = 1;
            appearance9.BackColor = System.Drawing.SystemColors.Window;
            appearance9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grid2.DisplayLayout.Override.ActiveCellAppearance = appearance9;
            appearance10.BackColor = System.Drawing.SystemColors.Highlight;
            appearance10.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grid2.DisplayLayout.Override.ActiveRowAppearance = appearance10;
            this.grid2.DisplayLayout.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.True;
            this.grid2.DisplayLayout.Override.AllowMultiCellOperations = ((Infragistics.Win.UltraWinGrid.AllowMultiCellOperation)((((((((Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Copy | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.CopyWithHeaders) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Cut) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Delete) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Paste) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Undo) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Redo) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Reserved)));
            this.grid2.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grid2.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance11.BackColor = System.Drawing.SystemColors.Window;
            this.grid2.DisplayLayout.Override.CardAreaAppearance = appearance11;
            appearance12.BorderColor = System.Drawing.Color.Silver;
            appearance12.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grid2.DisplayLayout.Override.CellAppearance = appearance12;
            this.grid2.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grid2.DisplayLayout.Override.CellPadding = 0;
            appearance13.BackColor = System.Drawing.SystemColors.Control;
            appearance13.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance13.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance13.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance13.BorderColor = System.Drawing.SystemColors.Window;
            this.grid2.DisplayLayout.Override.GroupByRowAppearance = appearance13;
            appearance14.TextHAlignAsString = "Left";
            this.grid2.DisplayLayout.Override.HeaderAppearance = appearance14;
            this.grid2.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grid2.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance15.BackColor = System.Drawing.SystemColors.Window;
            appearance15.BorderColor = System.Drawing.Color.Silver;
            this.grid2.DisplayLayout.Override.RowAppearance = appearance15;
            this.grid2.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance16.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grid2.DisplayLayout.Override.TemplateAddRowAppearance = appearance16;
            this.grid2.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grid2.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grid2.DisplayLayout.SelectionOverlayBorderThickness = 2;
            this.grid2.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grid2.EnterNextRowEnable = true;
            this.grid2.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.grid2.Location = new System.Drawing.Point(7, 17);
            this.grid2.Name = "grid2";
            this.grid2.Size = new System.Drawing.Size(800, 466);
            this.grid2.TabIndex = 756;
            this.grid2.Text = "grid1";
            this.grid2.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.grid2.UpdateMode = Infragistics.Win.UltraWinGrid.UpdateMode.OnCellChange;
            this.grid2.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.grid2.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.grid5);
            this.groupBox5.Location = new System.Drawing.Point(827, 549);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1046, 425);
            this.groupBox5.TabIndex = 757;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "���ϰ�ȹ";
            // 
            // grid5
            // 
            this.grid5.AutoResizeColumn = true;
            this.grid5.AutoUserColumn = true;
            this.grid5.ContextMenuCopyEnabled = true;
            this.grid5.ContextMenuDeleteEnabled = true;
            this.grid5.ContextMenuExcelEnabled = true;
            this.grid5.ContextMenuInsertEnabled = true;
            this.grid5.ContextMenuPasteEnabled = true;
            this.grid5.DeleteButtonEnable = true;
            appearance49.BackColor = System.Drawing.SystemColors.Window;
            appearance49.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grid5.DisplayLayout.Appearance = appearance49;
            this.grid5.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grid5.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            this.grid5.DisplayLayout.DefaultSelectedBackColor = System.Drawing.Color.Empty;
            appearance50.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance50.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance50.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance50.BorderColor = System.Drawing.SystemColors.Window;
            this.grid5.DisplayLayout.GroupByBox.Appearance = appearance50;
            appearance51.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid5.DisplayLayout.GroupByBox.BandLabelAppearance = appearance51;
            this.grid5.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grid5.DisplayLayout.GroupByBox.Hidden = true;
            appearance52.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance52.BackColor2 = System.Drawing.SystemColors.Control;
            appearance52.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance52.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid5.DisplayLayout.GroupByBox.PromptAppearance = appearance52;
            this.grid5.DisplayLayout.MaxColScrollRegions = 1;
            this.grid5.DisplayLayout.MaxRowScrollRegions = 1;
            appearance53.BackColor = System.Drawing.SystemColors.Window;
            appearance53.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grid5.DisplayLayout.Override.ActiveCellAppearance = appearance53;
            appearance54.BackColor = System.Drawing.SystemColors.Highlight;
            appearance54.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grid5.DisplayLayout.Override.ActiveRowAppearance = appearance54;
            this.grid5.DisplayLayout.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.True;
            this.grid5.DisplayLayout.Override.AllowMultiCellOperations = ((Infragistics.Win.UltraWinGrid.AllowMultiCellOperation)((((((((Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Copy | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.CopyWithHeaders) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Cut) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Delete) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Paste) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Undo) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Redo) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Reserved)));
            this.grid5.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grid5.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance55.BackColor = System.Drawing.SystemColors.Window;
            this.grid5.DisplayLayout.Override.CardAreaAppearance = appearance55;
            appearance56.BorderColor = System.Drawing.Color.Silver;
            appearance56.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grid5.DisplayLayout.Override.CellAppearance = appearance56;
            this.grid5.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grid5.DisplayLayout.Override.CellPadding = 0;
            appearance57.BackColor = System.Drawing.SystemColors.Control;
            appearance57.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance57.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance57.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance57.BorderColor = System.Drawing.SystemColors.Window;
            this.grid5.DisplayLayout.Override.GroupByRowAppearance = appearance57;
            appearance58.TextHAlignAsString = "Left";
            this.grid5.DisplayLayout.Override.HeaderAppearance = appearance58;
            this.grid5.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grid5.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance59.BackColor = System.Drawing.SystemColors.Window;
            appearance59.BorderColor = System.Drawing.Color.Silver;
            this.grid5.DisplayLayout.Override.RowAppearance = appearance59;
            this.grid5.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance60.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grid5.DisplayLayout.Override.TemplateAddRowAppearance = appearance60;
            this.grid5.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grid5.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grid5.DisplayLayout.SelectionOverlayBorderThickness = 2;
            this.grid5.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grid5.EnterNextRowEnable = true;
            this.grid5.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.grid5.Location = new System.Drawing.Point(6, 17);
            this.grid5.Name = "grid5";
            this.grid5.Size = new System.Drawing.Size(1034, 472);
            this.grid5.TabIndex = 756;
            this.grid5.Text = "grid3";
            this.grid5.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.grid5.UpdateMode = Infragistics.Win.UltraWinGrid.UpdateMode.OnCellChange;
            this.grid5.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.grid5.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.grid5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.grid3_KeyDown);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.grid1);
            this.groupBox3.Location = new System.Drawing.Point(8, 107);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(813, 436);
            this.groupBox3.TabIndex = 757;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "��������";
            // 
            // grid1
            // 
            this.grid1.AutoResizeColumn = true;
            this.grid1.AutoUserColumn = true;
            this.grid1.ContextMenuCopyEnabled = true;
            this.grid1.ContextMenuDeleteEnabled = true;
            this.grid1.ContextMenuExcelEnabled = true;
            this.grid1.ContextMenuInsertEnabled = true;
            this.grid1.ContextMenuPasteEnabled = true;
            this.grid1.DeleteButtonEnable = true;
            appearance18.BackColor = System.Drawing.SystemColors.Window;
            appearance18.BorderColor = System.Drawing.SystemColors.InactiveCaption;
            this.grid1.DisplayLayout.Appearance = appearance18;
            this.grid1.DisplayLayout.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grid1.DisplayLayout.CaptionVisible = Infragistics.Win.DefaultableBoolean.False;
            this.grid1.DisplayLayout.DefaultSelectedBackColor = System.Drawing.Color.Empty;
            appearance19.BackColor = System.Drawing.SystemColors.ActiveBorder;
            appearance19.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance19.BackGradientStyle = Infragistics.Win.GradientStyle.Vertical;
            appearance19.BorderColor = System.Drawing.SystemColors.Window;
            this.grid1.DisplayLayout.GroupByBox.Appearance = appearance19;
            appearance20.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid1.DisplayLayout.GroupByBox.BandLabelAppearance = appearance20;
            this.grid1.DisplayLayout.GroupByBox.BorderStyle = Infragistics.Win.UIElementBorderStyle.Solid;
            this.grid1.DisplayLayout.GroupByBox.Hidden = true;
            appearance21.BackColor = System.Drawing.SystemColors.ControlLightLight;
            appearance21.BackColor2 = System.Drawing.SystemColors.Control;
            appearance21.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance21.ForeColor = System.Drawing.SystemColors.GrayText;
            this.grid1.DisplayLayout.GroupByBox.PromptAppearance = appearance21;
            this.grid1.DisplayLayout.MaxColScrollRegions = 1;
            this.grid1.DisplayLayout.MaxRowScrollRegions = 1;
            appearance23.BackColor = System.Drawing.SystemColors.Window;
            appearance23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grid1.DisplayLayout.Override.ActiveCellAppearance = appearance23;
            appearance25.BackColor = System.Drawing.SystemColors.Highlight;
            appearance25.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.grid1.DisplayLayout.Override.ActiveRowAppearance = appearance25;
            this.grid1.DisplayLayout.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.True;
            this.grid1.DisplayLayout.Override.AllowMultiCellOperations = ((Infragistics.Win.UltraWinGrid.AllowMultiCellOperation)((((((((Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Copy | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.CopyWithHeaders) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Cut) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Delete) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Paste) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Undo) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Redo) 
            | Infragistics.Win.UltraWinGrid.AllowMultiCellOperation.Reserved)));
            this.grid1.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.Dotted;
            this.grid1.DisplayLayout.Override.BorderStyleRow = Infragistics.Win.UIElementBorderStyle.Dotted;
            appearance26.BackColor = System.Drawing.SystemColors.Window;
            this.grid1.DisplayLayout.Override.CardAreaAppearance = appearance26;
            appearance27.BorderColor = System.Drawing.Color.Silver;
            appearance27.TextTrimming = Infragistics.Win.TextTrimming.EllipsisCharacter;
            this.grid1.DisplayLayout.Override.CellAppearance = appearance27;
            this.grid1.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.EditAndSelectText;
            this.grid1.DisplayLayout.Override.CellPadding = 0;
            appearance28.BackColor = System.Drawing.SystemColors.Control;
            appearance28.BackColor2 = System.Drawing.SystemColors.ControlDark;
            appearance28.BackGradientAlignment = Infragistics.Win.GradientAlignment.Element;
            appearance28.BackGradientStyle = Infragistics.Win.GradientStyle.Horizontal;
            appearance28.BorderColor = System.Drawing.SystemColors.Window;
            this.grid1.DisplayLayout.Override.GroupByRowAppearance = appearance28;
            appearance29.TextHAlignAsString = "Left";
            this.grid1.DisplayLayout.Override.HeaderAppearance = appearance29;
            this.grid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;
            this.grid1.DisplayLayout.Override.HeaderStyle = Infragistics.Win.HeaderStyle.WindowsXPCommand;
            appearance30.BackColor = System.Drawing.SystemColors.Window;
            appearance30.BorderColor = System.Drawing.Color.Silver;
            this.grid1.DisplayLayout.Override.RowAppearance = appearance30;
            this.grid1.DisplayLayout.Override.RowSelectors = Infragistics.Win.DefaultableBoolean.False;
            appearance31.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grid1.DisplayLayout.Override.TemplateAddRowAppearance = appearance31;
            this.grid1.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill;
            this.grid1.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate;
            this.grid1.DisplayLayout.SelectionOverlayBorderThickness = 2;
            this.grid1.DisplayLayout.ViewStyleBand = Infragistics.Win.UltraWinGrid.ViewStyleBand.OutlookGroupBy;
            this.grid1.EnterNextRowEnable = true;
            this.grid1.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.grid1.Location = new System.Drawing.Point(6, 18);
            this.grid1.Name = "grid1";
            this.grid1.Size = new System.Drawing.Size(801, 412);
            this.grid1.TabIndex = 756;
            this.grid1.Text = "grid4";
            this.grid1.TextRenderingMode = Infragistics.Win.TextRenderingMode.GDI;
            this.grid1.UpdateMode = Infragistics.Win.UltraWinGrid.UpdateMode.OnCellChange;
            this.grid1.UseFlatMode = Infragistics.Win.DefaultableBoolean.True;
            this.grid1.UseOsThemes = Infragistics.Win.DefaultableBoolean.False;
            this.grid1.ClickCell += new Infragistics.Win.UltraWinGrid.ClickCellEventHandler(this.grid1_ClickCell);
            // 
            // cbo_GUBUN
            // 
            this.cbo_GUBUN.AutoSize = false;
            this.cbo_GUBUN.Font = new System.Drawing.Font("���� ����", 10F);
            this.cbo_GUBUN.Location = new System.Drawing.Point(564, 59);
            this.cbo_GUBUN.Name = "cbo_GUBUN";
            this.cbo_GUBUN.Size = new System.Drawing.Size(131, 27);
            this.cbo_GUBUN.TabIndex = 740;
            // 
            // sLabel2
            // 
            appearance47.BackColor = System.Drawing.Color.Transparent;
            appearance47.FontData.BoldAsString = "False";
            appearance47.FontData.UnderlineAsString = "False";
            appearance47.ForeColor = System.Drawing.Color.Black;
            appearance47.TextHAlignAsString = "Left";
            appearance47.TextVAlignAsString = "Middle";
            this.sLabel2.Appearance = appearance47;
            this.sLabel2.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel2.DbField = null;
            this.sLabel2.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel2.Location = new System.Drawing.Point(496, 59);
            this.sLabel2.Name = "sLabel2";
            this.sLabel2.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel2.Size = new System.Drawing.Size(104, 25);
            this.sLabel2.TabIndex = 739;
            this.sLabel2.Text = "���걸��";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Font = new System.Drawing.Font("���� ����", 15F, System.Drawing.FontStyle.Bold);
            this.btnSave.Location = new System.Drawing.Point(1754, 38);
            this.btnSave.Margin = new System.Windows.Forms.Padding(0);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(119, 46);
            this.btnSave.TabIndex = 758;
            this.btnSave.Text = "���";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtCYCLETIME
            // 
            appearance1.FontData.BoldAsString = "False";
            appearance1.FontData.UnderlineAsString = "False";
            appearance1.ForeColor = System.Drawing.Color.Black;
            this.txtCYCLETIME.Appearance = appearance1;
            this.txtCYCLETIME.AutoSize = false;
            this.txtCYCLETIME.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtCYCLETIME.Location = new System.Drawing.Point(792, 61);
            this.txtCYCLETIME.Name = "txtCYCLETIME";
            this.txtCYCLETIME.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtCYCLETIME.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtCYCLETIME.Size = new System.Drawing.Size(120, 27);
            this.txtCYCLETIME.TabIndex = 752;
            // 
            // sLabel19
            // 
            appearance24.BackColor = System.Drawing.Color.Transparent;
            appearance24.FontData.BoldAsString = "False";
            appearance24.FontData.UnderlineAsString = "False";
            appearance24.ForeColor = System.Drawing.Color.Black;
            appearance24.TextHAlignAsString = "Left";
            appearance24.TextVAlignAsString = "Middle";
            this.sLabel19.Appearance = appearance24;
            this.sLabel19.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel19.DbField = null;
            this.sLabel19.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel19.Location = new System.Drawing.Point(711, 58);
            this.sLabel19.Name = "sLabel19";
            this.sLabel19.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel19.Size = new System.Drawing.Size(76, 25);
            this.sLabel19.TabIndex = 751;
            this.sLabel19.Text = "Cycle Time";
            // 
            // dtp_STARTDATE
            // 
            this.dtp_STARTDATE.CustomFormat = "yyyy-MM-dd";
            this.dtp_STARTDATE.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_STARTDATE.Location = new System.Drawing.Point(792, 27);
            this.dtp_STARTDATE.Name = "dtp_STARTDATE";
            this.dtp_STARTDATE.Size = new System.Drawing.Size(120, 25);
            this.dtp_STARTDATE.TabIndex = 742;
            this.dtp_STARTDATE.ValueChanged += new System.EventHandler(this.dtp_STARTDATE_ValueChanged);
            // 
            // sLabel14
            // 
            appearance4.BackColor = System.Drawing.Color.Transparent;
            appearance4.FontData.BoldAsString = "False";
            appearance4.FontData.UnderlineAsString = "False";
            appearance4.ForeColor = System.Drawing.Color.Black;
            appearance4.TextHAlignAsString = "Left";
            appearance4.TextVAlignAsString = "Middle";
            this.sLabel14.Appearance = appearance4;
            this.sLabel14.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel14.DbField = null;
            this.sLabel14.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel14.Location = new System.Drawing.Point(711, 26);
            this.sLabel14.Name = "sLabel14";
            this.sLabel14.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel14.Size = new System.Drawing.Size(104, 25);
            this.sLabel14.TabIndex = 743;
            this.sLabel14.Text = "��������";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtRECENTHO);
            this.groupBox1.Controls.Add(this.txtDATE);
            this.groupBox1.Controls.Add(this.sLabel10);
            this.groupBox1.Controls.Add(this.sLabel8);
            this.groupBox1.Location = new System.Drawing.Point(1275, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(434, 68);
            this.groupBox1.TabIndex = 739;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "�ֱ� �������� ";
            // 
            // txtRECENTHO
            // 
            appearance32.FontData.BoldAsString = "False";
            appearance32.FontData.UnderlineAsString = "False";
            appearance32.ForeColor = System.Drawing.Color.Black;
            this.txtRECENTHO.Appearance = appearance32;
            this.txtRECENTHO.AutoSize = false;
            this.txtRECENTHO.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtRECENTHO.Location = new System.Drawing.Point(98, 27);
            this.txtRECENTHO.Name = "txtRECENTHO";
            this.txtRECENTHO.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtRECENTHO.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtRECENTHO.Size = new System.Drawing.Size(125, 27);
            this.txtRECENTHO.TabIndex = 739;
            // 
            // txtDATE
            // 
            appearance22.FontData.BoldAsString = "False";
            appearance22.FontData.UnderlineAsString = "False";
            appearance22.ForeColor = System.Drawing.Color.Black;
            this.txtDATE.Appearance = appearance22;
            this.txtDATE.AutoSize = false;
            this.txtDATE.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtDATE.Location = new System.Drawing.Point(296, 27);
            this.txtDATE.Name = "txtDATE";
            this.txtDATE.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtDATE.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtDATE.Size = new System.Drawing.Size(125, 27);
            this.txtDATE.TabIndex = 737;
            // 
            // sLabel10
            // 
            appearance48.BackColor = System.Drawing.Color.Transparent;
            appearance48.FontData.BoldAsString = "False";
            appearance48.FontData.UnderlineAsString = "False";
            appearance48.ForeColor = System.Drawing.Color.Black;
            appearance48.TextHAlignAsString = "Left";
            appearance48.TextVAlignAsString = "Middle";
            this.sLabel10.Appearance = appearance48;
            this.sLabel10.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel10.DbField = null;
            this.sLabel10.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel10.Location = new System.Drawing.Point(229, 28);
            this.sLabel10.Name = "sLabel10";
            this.sLabel10.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel10.Size = new System.Drawing.Size(104, 25);
            this.sLabel10.TabIndex = 738;
            this.sLabel10.Text = "��������";
            // 
            // sLabel8
            // 
            appearance61.BackColor = System.Drawing.Color.Transparent;
            appearance61.FontData.BoldAsString = "False";
            appearance61.FontData.UnderlineAsString = "False";
            appearance61.ForeColor = System.Drawing.Color.Black;
            appearance61.TextHAlignAsString = "Left";
            appearance61.TextVAlignAsString = "Middle";
            this.sLabel8.Appearance = appearance61;
            this.sLabel8.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel8.DbField = null;
            this.sLabel8.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel8.Location = new System.Drawing.Point(7, 28);
            this.sLabel8.Name = "sLabel8";
            this.sLabel8.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel8.Size = new System.Drawing.Size(104, 25);
            this.sLabel8.TabIndex = 735;
            this.sLabel8.Text = "�ֱ� ����ȣ��";
            // 
            // txtVEND
            // 
            appearance33.FontData.BoldAsString = "False";
            appearance33.FontData.UnderlineAsString = "False";
            appearance33.ForeColor = System.Drawing.Color.Black;
            this.txtVEND.Appearance = appearance33;
            this.txtVEND.AutoSize = false;
            this.txtVEND.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtVEND.Location = new System.Drawing.Point(564, 26);
            this.txtVEND.Name = "txtVEND";
            this.txtVEND.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtVEND.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtVEND.Size = new System.Drawing.Size(131, 27);
            this.txtVEND.TabIndex = 728;
            // 
            // sLabel6
            // 
            appearance34.BackColor = System.Drawing.Color.Transparent;
            appearance34.FontData.BoldAsString = "False";
            appearance34.FontData.UnderlineAsString = "False";
            appearance34.ForeColor = System.Drawing.Color.Black;
            appearance34.TextHAlignAsString = "Left";
            appearance34.TextVAlignAsString = "Middle";
            this.sLabel6.Appearance = appearance34;
            this.sLabel6.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel6.DbField = null;
            this.sLabel6.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel6.Location = new System.Drawing.Point(496, 28);
            this.sLabel6.Name = "sLabel6";
            this.sLabel6.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel6.Size = new System.Drawing.Size(104, 25);
            this.sLabel6.TabIndex = 729;
            this.sLabel6.Text = "������";
            // 
            // txtBARCODE
            // 
            this.txtBARCODE.BackColor = System.Drawing.Color.White;
            this.txtBARCODE.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBARCODE.Font = new System.Drawing.Font("���� ����", 15F);
            this.txtBARCODE.Location = new System.Drawing.Point(119, 25);
            this.txtBARCODE.Name = "txtBARCODE";
            this.txtBARCODE.Size = new System.Drawing.Size(364, 27);
            this.txtBARCODE.TabIndex = 715;
            // 
            // sLabel5
            // 
            appearance3.BackColor = System.Drawing.Color.Transparent;
            appearance3.FontData.BoldAsString = "False";
            appearance3.FontData.UnderlineAsString = "False";
            appearance3.ForeColor = System.Drawing.Color.Black;
            appearance3.TextHAlignAsString = "Left";
            appearance3.TextVAlignAsString = "Middle";
            this.sLabel5.Appearance = appearance3;
            this.sLabel5.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel5.DbField = null;
            this.sLabel5.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel5.Location = new System.Drawing.Point(15, 27);
            this.sLabel5.Name = "sLabel5";
            this.sLabel5.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel5.Size = new System.Drawing.Size(104, 25);
            this.sLabel5.TabIndex = 710;
            this.sLabel5.Text = "���� Lot���� ";
            // 
            // txtPROD
            // 
            appearance2.FontData.BoldAsString = "False";
            appearance2.FontData.UnderlineAsString = "False";
            appearance2.ForeColor = System.Drawing.Color.Black;
            this.txtPROD.Appearance = appearance2;
            this.txtPROD.AutoSize = false;
            this.txtPROD.Font = new System.Drawing.Font("���� ����", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtPROD.Location = new System.Drawing.Point(119, 58);
            this.txtPROD.Name = "txtPROD";
            this.txtPROD.RequireFlag = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtPROD.RequirePop = WIZ.Control.STextBox.RequireFlagEnum.NO;
            this.txtPROD.Size = new System.Drawing.Size(364, 27);
            this.txtPROD.TabIndex = 56;
            // 
            // sLabel1
            // 
            appearance17.BackColor = System.Drawing.Color.Transparent;
            appearance17.FontData.BoldAsString = "False";
            appearance17.FontData.UnderlineAsString = "False";
            appearance17.ForeColor = System.Drawing.Color.Black;
            appearance17.TextHAlignAsString = "Left";
            appearance17.TextVAlignAsString = "Middle";
            this.sLabel1.Appearance = appearance17;
            this.sLabel1.BorderStyleInner = Infragistics.Win.UIElementBorderStyle.None;
            this.sLabel1.DbField = null;
            this.sLabel1.Font = new System.Drawing.Font("���� ����", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sLabel1.Location = new System.Drawing.Point(15, 59);
            this.sLabel1.Name = "sLabel1";
            this.sLabel1.RequireFlag = WIZ.Control.SLabel.RequireFlagEnum.NO;
            this.sLabel1.Size = new System.Drawing.Size(104, 25);
            this.sLabel1.TabIndex = 245;
            this.sLabel1.Text = "�� ���� ��ǰ��";
            // 
            // PL0110_POP
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1889, 988);
            this.Name = "PL0110_POP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "��ǰ ��ȹ ���";
            this.Load += new System.EventHandler(this.PL0110_POP_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gbxHeader)).EndInit();
            this.gbxHeader.ResumeLayout(false);
            this.gbxHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gbxBody)).EndInit();
            this.gbxBody.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraGroupBox2)).EndInit();
            this.ultraGroupBox2.ResumeLayout(false);
            this.ultraGroupBox2.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid4)).EndInit();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid2)).EndInit();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid5)).EndInit();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbo_GUBUN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCYCLETIME)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtRECENTHO)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDATE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVEND)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPROD)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox txtREPAIRCODE;
        private Infragistics.Win.Misc.UltraGroupBox ultraGroupBox2;
        private Control.SLabel sLabel5;
        private System.Windows.Forms.TextBox txtBARCODE;
        private System.Windows.Forms.GroupBox groupBox1;
        private Control.STextBox txtDATE;
        private Control.SLabel sLabel10;
        private Control.SLabel sLabel8;
        private Control.STextBox txtVEND;
        private Control.SLabel sLabel6;
        private Control.STextBox txtPROD;
        private Control.SLabel sLabel1;
        private Control.STextBox txtCYCLETIME;
        private Control.SLabel sLabel19;
        private System.Windows.Forms.DateTimePicker dtp_STARTDATE;
        private Control.SLabel sLabel14;
        private Infragistics.Win.Misc.UltraButton btnSave;
        private Infragistics.Win.UltraWinEditors.UltraComboEditor cbo_GUBUN;
        private Control.SLabel sLabel2;
        private System.Windows.Forms.GroupBox groupBox3;
        private Control.Grid grid1;
        private System.Windows.Forms.GroupBox groupBox5;
        private Control.Grid grid5;
        private System.Windows.Forms.GroupBox groupBox4;
        private Control.Grid grid2;
        private System.Windows.Forms.GroupBox groupBox6;
        private Control.Grid grid4;
        private System.Windows.Forms.GroupBox groupBox7;
        private Infragistics.Win.Misc.UltraButton btn_INSERTROW;
        private Infragistics.Win.Misc.UltraButton ultraButton3;
        private System.Windows.Forms.CheckBox chk_DAY;
        private Control.STextBox txtRECENTHO;
    }
}